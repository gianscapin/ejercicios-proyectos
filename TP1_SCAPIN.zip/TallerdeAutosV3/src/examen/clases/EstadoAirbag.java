package examen.clases;

public enum EstadoAirbag {
	OK, DEFECTUOSO, NO_POSEE
}
