package examen.clases;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import ort.tp1.tdas.implementaciones.ColaNodos;
import ort.tp1.tdas.interfaces.Cola;

public class Taller {
	private static final int MAX_TRABAJOS_DIARIOS = 50;
	private static float PRECIO_HORA = 3000;
	private static Scanner input = new Scanner(System.in);
	private static final int TIPOS_SERVICIOS_POSIBLES = 5;
	private Cola<Vehiculo> vehiculosEnPuerta;
	private Servicio[] servicios;
	private ArrayList<Trabajo> trabajosRealizados;
	private ListaTrabajosPendientes trabajosPendientes;

	public Taller() {
		vehiculosEnPuerta = new ColaNodos<Vehiculo>(MAX_TRABAJOS_DIARIOS);
		servicios = new Servicio[TIPOS_SERVICIOS_POSIBLES];
		trabajosRealizados = new ArrayList<Trabajo>();
		trabajosPendientes = new ListaTrabajosPendientes();
		cargarServicios();
	}

	/**
	 * Procesa el ingreso de un vehiculo
	 * @param patente
	 * @param marca
	 * @param airbag
	 */
	public void agregarVehiculoEnEspera(String patente, String marca, EstadoAirbag airbag) {
		Vehiculo vehiculo = new Auto(patente,marca,airbag);
		vehiculosEnPuerta.add(vehiculo);
	}

	/**
	 * Procesa el ingreso de un vehiculo
	 * @param patente
	 * @param marca
	 * @param cilindrada
	 * @param tieneLimitador
	 */
	public void agregarVehiculoEnEspera(String patente, String marca, int cilindrada, boolean tieneLimitador) {
		Vehiculo vehiculo = new Moto(patente,marca,cilindrada,tieneLimitador);
		vehiculosEnPuerta.add(vehiculo);
	}

	/**
	 * Procesa el ingreso de un vehiculo
	 * @param vehiculo
	 */
	private void agregarVehiculoEnEspera(Vehiculo vehiculo) {
		vehiculosEnPuerta.add(vehiculo);
	}

	/**
	 * Crea una estructura a nivel de la clase que guarda todos los servicios
	 * posibles, los que luego serán asignados a los vehiculos que ingresen al
	 * taller.
	 */
	public void cargarServicios() {
		String[] nombresServicios = { "Cambio de Bateria", "Cambio Aceite y Filtro", "Alineacion y Balanceo",
				"Cambio amortiguadores", "Servicio completo" };
		float[] duracionEstimadaServicio = { 0.5f, 1, 1.5f, 2, 3 };
		String descripcion;
		float horas;
		int codigo=1;
		for(int i = 0;i<TIPOS_SERVICIOS_POSIBLES;i++) {
			descripcion = nombresServicios[i];
			horas = duracionEstimadaServicio[i];
			servicios[i] = new Servicio(codigo,descripcion,horas);
			codigo++;
		}
	}

	private Trabajo crearTrabajo(Vehiculo vehiculo) {
		int numero = 0;
		numero = pedirServicio();
		Servicio servicio = servicios[numero - 1];
		Trabajo trabajo = new Trabajo(vehiculo, servicio);
		return trabajo;
	}

	public void informarImporteServicios() {
		float total = 0;
		for (Trabajo trabajo : trabajosRealizados) {
			System.out.println(trabajo);
			total += trabajo.getImporte();
		}
		System.out.println("La recaudacion del dia fue:" + total);
	}

	/**
	 * Genera e informa la cantidad de servicios realizados para cada tipo de servicio.
	 */
	public void informarResumenServicios() {
		// TODO - Para los que deben Arrays: Reemplazar por lo correcto y
		// completar
		int[] cantidadPorServicios = new int[TIPOS_SERVICIOS_POSIBLES];
		for(Trabajo trabajoActual:trabajosRealizados) {
			cantidadPorServicios[trabajoActual.getService().getCodigo()-1]++;
		}
		for(int i = 0; i<cantidadPorServicios.length;i++) {
			System.out.println(servicios[i].getDesc()+": "+cantidadPorServicios[i]);
		}
	}

	private void mostrarMenuServicios() {
		for (int i = 0; i < servicios.length; i++) {
			System.out.println(servicios[i]);
		}
	}

	private int pedirServicio() {
		int numero = 0;
		boolean ok = false;
		while (!ok) {
			try {
				mostrarMenuServicios();
				System.out.println("Solicite un servicio 1-5:");
				numero = input.nextInt();
				if (numero > 0 && numero <= servicios.length) {
					ok = true;
				}
			} catch (InputMismatchException e) {
				System.out.println("Error. Ingrese un numero correcto");
			} finally {
				input.nextLine();
			}
		}
		return numero;
	}

	/**
	 * Asumiendo que ya todos los vhículos en espera son validos agrega
	 * a cada uno a los trabajos pendientes. Al agregarlos pide tambien
	 * el servicio a realizar. (Para crear un Trabajo hacen falta un
	 * Vehiculo y un Servicio=.
	 */
	public void procesarIngresoVehiculos() {
		// TODO - Implementar. Usa el metodo crearTrabajo
		Vehiculo vehiculo;
		Trabajo trabajo;
		while(!vehiculosEnPuerta.isEmpty()) {
			vehiculo = vehiculosEnPuerta.remove();
			trabajo = crearTrabajo(vehiculo);
			trabajosPendientes.add(trabajo);
			System.out.println("Ingreso el vehiculo patente "+vehiculo.getPatente());
		}
	}

	public void procesarServicios() {
		Trabajo trabajo;
		while (!trabajosPendientes.isEmpty()) {
			trabajo = trabajosPendientes.removeAt(0);
			trabajo.aplicarPrecioHora(PRECIO_HORA);
			trabajosRealizados.add(trabajo);
		}
	}

	public void reportarTrabajosPendientes() {
		trabajosPendientes.reportar();
	}

	/**
	 * Para evitar contratiempos chequea que los vehiculos que esperan
	 * en la puerta cumplan con las nuevas condiciones de atencion.
	 * Como puede procesarse mas de una vez debe asegurarse de mantener
	 * el orden de los vehiculos en puerta.
	 */
	public void revisarVehiculosEnPuerta() {
		System.out.println("Vehiculos que no pueden ingresar al taller");
		Auto centinela = new Auto("patenteasd","asdjkarmarca",EstadoAirbag.DEFECTUOSO);
		vehiculosEnPuerta.add(centinela);
		Vehiculo vehiculoActual = vehiculosEnPuerta.remove();
		while(vehiculoActual!=centinela) {
			if(vehiculoActual.autoDiagnostico()) {
				vehiculosEnPuerta.add(vehiculoActual);
			}else {
				System.out.println("El vehiculo patente "+vehiculoActual.getPatente()+" no cumple con los requisitos y es rechazado.");
			}
			vehiculoActual = vehiculosEnPuerta.remove();
		}
	}

}