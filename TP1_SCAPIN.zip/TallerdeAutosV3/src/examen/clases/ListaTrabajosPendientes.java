package examen.clases;

import ort.tp1.tdas.implementaciones.ListaOrdenadaNodos;

public class ListaTrabajosPendientes extends ListaOrdenadaNodos<Integer,Trabajo> implements Reportable {
	public ListaTrabajosPendientes() {
		
	}
	@Override
	public int compare(Trabajo t1, Trabajo t2) {
		return 1-(int)(t2.getService().getHoras() - t1.getService().getHoras());
	}
	
	@Override
	public int compareByKey(Integer horas, Trabajo t1) {
		return (horas - (int)t1.getService().getHoras());
	}
	
	@Override
	public void reportar() {
		for(Trabajo trabajoActual:this) {
			trabajoActual.reportar();
		}
	}
}
