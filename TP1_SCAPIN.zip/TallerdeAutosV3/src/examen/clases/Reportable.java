package examen.clases;

public interface Reportable {
    public void reportar();
}
