package examen.clases;

public class Trabajo implements Reportable {
	private Servicio servicio;
	private Vehiculo vehiculo;
	private float importe;

	public Trabajo(Vehiculo vehiculo, Servicio trabajo) {
		this.importe = 0;
		setVehiculo(vehiculo);
		setServicio(trabajo);
	}
	
	private void setVehiculo(Vehiculo vehiculo) {
		if(vehiculo==null) {
			throw new IllegalArgumentException("El trabajo debe crearse con un vehiculo asignado.");
		}
		this.vehiculo = vehiculo;
	}
	
	private void setServicio(Servicio trabajo) {
		if(trabajo==null) {
			throw new IllegalArgumentException("el trabajo debe crearse con un servicio asignado.");
		}
		this.servicio = trabajo;
	}

	public int getCodigo() {
		return servicio.getCodigo();
	}

	public Servicio getService() {
		return servicio;
	}

	@Override
	public void reportar() {
		System.out.println("[" + vehiculo.getClass().getSimpleName() + " patente " + vehiculo.getPatente()
				+ " servicio a realizar " + servicio.getDesc() + "]");
	}

	public void aplicarPrecioHora(float precioHora) {
		importe = servicio.getHoras() * precioHora;
	}

	public float getImporte() {
		return importe;
	}

	@Override
	public String toString() {
		return "Trabajo [servicio=" + servicio + ", vehiculo=" + vehiculo + ", importe=" + importe + "]";
	}

}
